/**
 * GRAN TRADE INC. — STONE CATALOG DATA MODULE
 * Complete wholesale inventory dataset with GT Numbers, Lot Numbers, Thicknesses, Sizes, and 2-Picture Views.
 */
(function (global) {
  "use strict";

  const STONES = [
    // ---------------- QUARTZ (GT-1000 series) ----------------
    {
      id: "calacatta-alps",
      name: "Calacatta Alps",
      gtNumber: "GT-1001",
      lotNumber: "LOT #84920",
      thickness: "3 cm",
      size: "128\" × 65\" · 57.8 sq. ft.",
      category: "quartz",
      categoryLabel: "Quartz",
      type: "engineered",
      typeLabel: "Engineered Quartz",
      finish: "Polished",
      origin: "Engineered (USA / Global)",
      colors: ["white", "grey"],
      colorLabel: "White, Alpine Grey",
      application: "Kitchen Countertops, Master Baths, Commercial Hospitality",
      description: "Crisp white background crossed with soft, sweeping alpine grey veining. Non-porous engineered surface requiring zero periodic sealing.",
      image1: "assets/images/stone-types/quartz.jpg",
      image2: "assets/images/stone-types/quartz.jpg",
      inStock: true
    },
    {
      id: "calacatta-gold",
      name: "Calacatta Gold",
      gtNumber: "GT-1002",
      lotNumber: "LOT #84921",
      thickness: "3 cm",
      size: "130\" × 65\" · 58.7 sq. ft.",
      category: "quartz",
      categoryLabel: "Quartz",
      type: "engineered",
      typeLabel: "Engineered Quartz",
      finish: "Polished",
      origin: "Engineered (USA / Global)",
      colors: ["white", "gold", "grey"],
      colorLabel: "Milky White, Amber Gold",
      application: "Luxury Waterfall Islands, Primary Bathroom Suites",
      description: "Luminous milky backdrop with warm amber and subtle graphite veins that emulate prestigious Italian Calacatta marble.",
      image1: "assets/images/stone-types/quartz.jpg",
      image2: "assets/images/stone-types/quartz.jpg",
      inStock: true
    },
    {
      id: "calacatta-panda",
      name: "Calacatta Panda",
      gtNumber: "GT-1003",
      lotNumber: "LOT #84922",
      thickness: "3 cm",
      size: "128\" × 64\" · 56.9 sq. ft.",
      category: "quartz",
      categoryLabel: "Quartz",
      type: "engineered",
      typeLabel: "Engineered Quartz",
      finish: "Polished",
      origin: "Engineered (USA / Global)",
      colors: ["white", "black"],
      colorLabel: "Stark White, Jet Black",
      application: "High-Contrast Kitchens, Feature Walls, Retail Showrooms",
      description: "Stark contrast statement piece featuring bold charcoal-black ribbons coursing through an immaculate white field.",
      image1: "assets/images/stone-types/quartz.jpg",
      image2: "assets/images/stone-types/quartz.jpg",
      inStock: true
    },
    {
      id: "calacatta-tuscany",
      name: "Calacatta Tuscany",
      gtNumber: "GT-1004",
      lotNumber: "LOT #84923",
      thickness: "3 cm",
      size: "132\" × 65\" · 59.6 sq. ft.",
      category: "quartz",
      categoryLabel: "Quartz",
      type: "engineered",
      typeLabel: "Engineered Quartz",
      finish: "Polished",
      origin: "Engineered (USA / Global)",
      colors: ["white", "gold"],
      colorLabel: "Ivory, Warm Honey",
      application: "Transitional Kitchens, Reception Counters, Vanities",
      description: "Soft ivory base highlighted by layered honey-tinted veining, balancing warmth with contemporary durability.",
      image1: "assets/images/stone-types/quartz.jpg",
      image2: "assets/images/stone-types/quartz.jpg",
      inStock: true
    },
    {
      id: "calacatta-vega",
      name: "Calacatta Vega",
      gtNumber: "GT-1005",
      lotNumber: "LOT #84924",
      thickness: "3 cm",
      size: "126\" × 63\" · 55.1 sq. ft.",
      category: "quartz",
      categoryLabel: "Quartz",
      type: "engineered",
      typeLabel: "Engineered Quartz",
      finish: "Polished",
      origin: "Engineered (USA / Global)",
      colors: ["white", "grey"],
      colorLabel: "Porcelain White, Linear Grey",
      application: "Island Waterfall Edges, Fireplace Surrounds",
      description: "Refined linear grey veining patterned in balanced rhythms across a clear porcelain-white surface.",
      image1: "assets/images/stone-types/quartz.jpg",
      image2: "assets/images/stone-types/quartz.jpg",
      inStock: true
    },
    {
      id: "nero-marquina-quartz",
      name: "Nero Marquina",
      gtNumber: "GT-1006",
      lotNumber: "LOT #84925",
      thickness: "3 cm",
      size: "128\" × 64\" · 56.9 sq. ft.",
      category: "quartz",
      categoryLabel: "Quartz",
      type: "engineered",
      typeLabel: "Engineered Quartz",
      finish: "Polished",
      origin: "Engineered (USA / Global)",
      colors: ["black", "white"],
      colorLabel: "Obsidian Black, Pure White",
      application: "Executive Cocktail Bars, Dark Powder Rooms, Custom Furniture",
      description: "Deep obsidian field electrified by fine, erratic white lightning streaks. Engineered for zero oil-staining.",
      image1: "assets/images/stone-types/quartz.jpg",
      image2: "assets/images/stone-types/quartz.jpg",
      inStock: true
    },
    {
      id: "organic-white",
      name: "Organic White",
      gtNumber: "GT-1007",
      lotNumber: "LOT #84926",
      thickness: "3 cm",
      size: "126\" × 63\" · 55.1 sq. ft.",
      category: "quartz",
      categoryLabel: "Quartz",
      type: "engineered",
      typeLabel: "Engineered Quartz",
      finish: "Polished",
      origin: "Engineered (USA / Global)",
      colors: ["white", "cream"],
      colorLabel: "Alabaster White, Cream",
      application: "Multi-Family Residential, Minimalist Kitchen Perimeters",
      description: "Subtle multi-toned off-white surface featuring fine mineral movement for an understated organic ambiance.",
      image1: "assets/images/stone-types/quartz.jpg",
      image2: "assets/images/stone-types/quartz.jpg",
      inStock: true
    },
    {
      id: "carrara-white-quartz",
      name: "Carrara White Quartz",
      gtNumber: "GT-1008",
      lotNumber: "LOT #84927",
      thickness: "3 cm",
      size: "128\" × 64\" · 56.9 sq. ft.",
      category: "quartz",
      categoryLabel: "Quartz",
      type: "engineered",
      typeLabel: "Engineered Quartz",
      finish: "Polished",
      origin: "Engineered (USA / Global)",
      colors: ["white", "grey"],
      colorLabel: "Carrara White, Feathery Grey",
      application: "Classic Shaker Kitchens, Rental Upgrades, Family Counters",
      description: "Traditional Carrara marbling rendered in stain-resistant engineered quartz. Feathery grey misting on white.",
      image1: "assets/images/stone-types/quartz.jpg",
      image2: "assets/images/stone-types/quartz.jpg",
      inStock: true
    },
    {
      id: "black-crystal-quartz",
      name: "Black Crystal Quartz",
      gtNumber: "GT-1009",
      lotNumber: "LOT #84928",
      thickness: "3 cm",
      size: "126\" × 63\" · 55.1 sq. ft.",
      category: "quartz",
      categoryLabel: "Quartz",
      type: "engineered",
      typeLabel: "Engineered Quartz",
      finish: "Polished",
      origin: "Engineered (USA / Global)",
      colors: ["black"],
      colorLabel: "Jet Black, Reflective Crystals",
      application: "Modern Bars, High-Tech Bathrooms, Commercial Vanities",
      description: "Uniform jet-black foundation studded with reflective micro-crystals that catch ambient overhead lighting.",
      image1: "assets/images/stone-types/quartz.jpg",
      image2: "assets/images/stone-types/quartz.jpg",
      inStock: true
    },
    {
      id: "zermatt",
      name: "Zermatt",
      gtNumber: "GT-1010",
      lotNumber: "LOT #84929",
      thickness: "3 cm",
      size: "130\" × 65\" · 58.7 sq. ft.",
      category: "quartz",
      categoryLabel: "Quartz",
      type: "engineered",
      typeLabel: "Engineered Quartz",
      finish: "Polished",
      origin: "Engineered (USA / Global)",
      colors: ["white", "grey"],
      colorLabel: "Glacier White, Ice Grey",
      application: "Architectural Islands, Scandinavian Kitchens",
      description: "Pristine white stone inspired by Swiss mountain glaciers, featuring ultra-fine cool grey undertones.",
      image1: "assets/images/stone-types/quartz.jpg",
      image2: "assets/images/stone-types/quartz.jpg",
      inStock: true
    },
    {
      id: "versilia",
      name: "Versilia",
      gtNumber: "GT-1011",
      lotNumber: "LOT #84930",
      thickness: "3 cm",
      size: "132\" × 65\" · 59.6 sq. ft.",
      category: "quartz",
      categoryLabel: "Quartz",
      type: "engineered",
      typeLabel: "Engineered Quartz",
      finish: "Polished",
      origin: "Engineered (USA / Global)",
      colors: ["white", "grey", "cream"],
      colorLabel: "Alabaster, Smoky Taupe",
      application: "Waterfall Islands, Seamless Kitchen Backsplashes",
      description: "Flowing broad veining in smoky taupe and warm grey over a creamy alabaster backdrop.",
      image1: "assets/images/stone-types/quartz.jpg",
      image2: "assets/images/stone-types/quartz.jpg",
      inStock: true
    },

    // ---------------- NATURAL GRANITE (GT-2000 series) ----------------
    {
      id: "absolute-black-polished",
      name: "Absolute Black Polished",
      gtNumber: "",
      lotNumber: "LOT #71201",
      thickness: "3 cm",
      size: "124\" × 76\" · 65.4 sq. ft.",
      category: "granite",
      categoryLabel: "Granite",
      type: "natural",
      typeLabel: "Natural Igneous Stone",
      finish: "Polished",
      origin: "India",
      colors: ["black"],
      colorLabel: "Deep Igneous Black",
      application: "High-Traffic Kitchens, Outdoor Barbecues, Commercial Thresholds",
      description: "Uniform deep black igneous granite with dense grain structure. Renowned worldwide for supreme hardness and low porosity.",
      image1: "assets/images/stone-types/granite.jpg",
      image2: "assets/images/stone-types/granite.jpg",
      inStock: true
    },
    {
      id: "black-galaxy",
      name: "Black Galaxy",
      gtNumber: "",
      lotNumber: "LOT #71202",
      thickness: "3 cm",
      size: "122\" × 74\" · 62.7 sq. ft.",
      category: "granite",
      categoryLabel: "Granite",
      type: "natural",
      typeLabel: "Natural Igneous Stone",
      finish: "Polished",
      origin: "India (Andhra Pradesh)",
      colors: ["black", "gold"],
      colorLabel: "Black, Golden Bronzite",
      application: "Statement Kitchen Counters, Fireplace Hearths",
      description: "Famous natural granite shimmering with natural bronzite and golden metallic flecks across a dark obsidian matrix.",
      image1: "assets/images/stone-types/granite.jpg",
      image2: "assets/images/stone-types/granite.jpg",
      inStock: true
    },
    {
      id: "blue-pearl",
      name: "Blue Pearl",
      gtNumber: "",
      lotNumber: "LOT #71203",
      thickness: "3 cm",
      size: "120\" × 72\" · 60.0 sq. ft.",
      category: "granite",
      categoryLabel: "Granite",
      type: "natural",
      typeLabel: "Natural Larvikite Stone",
      finish: "Polished",
      origin: "Norway (Larvik)",
      colors: ["blue", "grey"],
      colorLabel: "Metallic Blue, Silver-Grey",
      application: "Luxury Bathrooms, Coastal Kitchens, Exterior Cladding",
      description: "Norwegian larvikite quarry cut packed with iridescent feldspar crystals that reflect vivid metallic silver-blue hues.",
      image1: "assets/images/stone-types/granite.jpg",
      image2: "assets/images/stone-types/granite.jpg",
      inStock: true
    },
    {
      id: "colonial-white",
      name: "Colonial White",
      gtNumber: "",
      lotNumber: "LOT #71204",
      thickness: "3 cm",
      size: "128\" × 75\" · 66.7 sq. ft.",
      category: "granite",
      categoryLabel: "Granite",
      type: "natural",
      typeLabel: "Natural Igneous Stone",
      finish: "Polished",
      origin: "India",
      colors: ["white", "grey", "brown"],
      colorLabel: "Creamy White, Garnet Flecks",
      application: "Farmhouse Kitchens, Bright Bathrooms, Full Backsplashes",
      description: "Creamy off-white field accented with soft smoke-grey smudges and burgundy garnet mineral flecks.",
      image1: "assets/images/stone-types/granite.jpg",
      image2: "assets/images/stone-types/granite.jpg",
      inStock: true
    },
    {
      id: "kashmir-white-leather",
      name: "Kashmir White Leather",
      gtNumber: "",
      lotNumber: "LOT #71205",
      thickness: "3 cm",
      size: "126\" × 74\" · 64.8 sq. ft.",
      category: "granite",
      categoryLabel: "Granite",
      type: "natural",
      typeLabel: "Natural Igneous Stone",
      finish: "Leathered",
      origin: "India (Tamil Nadu)",
      colors: ["white", "grey", "red"],
      colorLabel: "Chalk White, Wine Garnets",
      application: "Tactile Kitchen Islands, Powder Room Vanities",
      description: "Soft tactile matte finish highlighting subtle grey veining and small garnet crystals. Velvet leather texture.",
      image1: "assets/images/stone-types/granite.jpg",
      image2: "assets/images/stone-types/granite.jpg",
      inStock: true
    },
    {
      id: "new-venetian-gold",
      name: "New Venetian Gold",
      gtNumber: "",
      lotNumber: "LOT #71206",
      thickness: "3 cm",
      size: "125\" × 73\" · 63.4 sq. ft.",
      category: "granite",
      categoryLabel: "Granite",
      type: "natural",
      typeLabel: "Natural Igneous Stone",
      finish: "Polished",
      origin: "Brazil",
      colors: ["gold", "cream", "brown"],
      colorLabel: "Warm Ochre, Amber, Brown",
      application: "Warm Traditional Kitchens, Wood Cabinetry Countertops",
      description: "Warm beige and golden-ochre stone peppered with deep brown, red, and slate flecks. Reliable residential workhorse.",
      image1: "assets/images/stone-types/granite.jpg",
      image2: "assets/images/stone-types/granite.jpg",
      inStock: true
    },
    {
      id: "ruby-red",
      name: "Ruby Red",
      gtNumber: "",
      lotNumber: "LOT #71207",
      thickness: "3 cm",
      size: "118\" × 70\" · 57.4 sq. ft.",
      category: "granite",
      categoryLabel: "Granite",
      type: "natural",
      typeLabel: "Natural Igneous Stone",
      finish: "Polished",
      origin: "India",
      colors: ["red", "black"],
      colorLabel: "Crimson Red, Charcoal",
      application: "Monument Base Works, Accent Flooring, Commercial Entries",
      description: "Intense crimson-red granite with rich black and blue-grey quartz crystals. Extremely hard and weather-impervious.",
      image1: "assets/images/stone-types/granite.jpg",
      image2: "assets/images/stone-types/granite.jpg",
      inStock: true
    },
    {
      id: "steel-grey-leather",
      name: "Steel Grey Leather",
      gtNumber: "",
      lotNumber: "LOT #71208",
      thickness: "3 cm",
      size: "128\" × 76\" · 67.5 sq. ft.",
      category: "granite",
      categoryLabel: "Granite",
      type: "natural",
      typeLabel: "Natural Igneous Stone",
      finish: "Leathered",
      origin: "India (Andhra Pradesh)",
      colors: ["grey", "black"],
      colorLabel: "Medium Slate, Charcoal Grey",
      application: "Industrial Modern Kitchens, Outdoor Kitchen Islands",
      description: "Medium to dark grey stone treated with textured wire brushing. Matte, fingerprint-resistant, and non-reflective.",
      image1: "assets/images/stone-types/granite.jpg",
      image2: "assets/images/stone-types/granite.jpg",
      inStock: true
    },
    {
      id: "tan-brown",
      name: "Tan Brown",
      gtNumber: "",
      lotNumber: "LOT #71209",
      thickness: "3 cm",
      size: "126\" × 75\" · 65.6 sq. ft.",
      category: "granite",
      categoryLabel: "Granite",
      type: "natural",
      typeLabel: "Natural Igneous Stone",
      finish: "Polished",
      origin: "India (Telangana)",
      colors: ["brown", "black"],
      colorLabel: "Chocolate Brown, Copper",
      application: "Heavy Cooking Prep Surfaces, Commercial Bar Tops",
      description: "Dark brown granite enriched with copper, chocolate, and black mineral deposits forming a rich pebbled tapestry.",
      image1: "assets/images/stone-types/granite.jpg",
      image2: "assets/images/stone-types/granite.jpg",
      inStock: true
    },
    {
      id: "emerald-pearl",
      name: "Emerald Pearl",
      gtNumber: "",
      lotNumber: "LOT #71210",
      thickness: "3 cm",
      size: "122\" × 72\" · 61.0 sq. ft.",
      category: "granite",
      categoryLabel: "Granite",
      type: "natural",
      typeLabel: "Natural Larvikite Stone",
      finish: "Polished",
      origin: "Norway (Larvik)",
      colors: ["green", "black"],
      colorLabel: "Deep Bottle Green, Silver Flecks",
      application: "Luxurious Bath Vanities, Polished Table Tops",
      description: "Deep green and charcoal larvikite with shimmering emerald and silver inclusions that glow under directional light.",
      image1: "assets/images/stone-types/granite.jpg",
      image2: "assets/images/stone-types/granite.jpg",
      inStock: true
    },
    {
      id: "black-forest",
      name: "Black Forest",
      gtNumber: "",
      lotNumber: "LOT #71211",
      thickness: "3 cm",
      size: "130\" × 78\" · 70.4 sq. ft.",
      category: "granite",
      categoryLabel: "Granite",
      type: "natural",
      typeLabel: "Natural Igneous Stone",
      finish: "Polished",
      origin: "Brazil",
      colors: ["black", "white", "grey"],
      colorLabel: "Jet Black, Flowing White Veins",
      application: "Dramatic Islands, Feature Backsplashes, Powder Rooms",
      description: "Dramatic Brazilian natural stone characterized by stark white ribbon veins coursing through a deep midnight background.",
      image1: "assets/images/stone-types/granite.jpg",
      image2: "assets/images/stone-types/granite.jpg",
      inStock: true
    },

    // ---------------- FINE MARBLE (GT-3000 series) ----------------
    {
      id: "bianco-carrara",
      name: "Bianco Carrara",
      gtNumber: "",
      lotNumber: "LOT #62011",
      thickness: "3 cm",
      size: "122\" × 70\" · 59.3 sq. ft.",
      category: "marble",
      categoryLabel: "Marble",
      type: "natural",
      typeLabel: "Natural Metamorphic Marble",
      finish: "Polished",
      origin: "Italy (Carrara)",
      colors: ["white", "grey"],
      colorLabel: "Milky White, Soft Graphite",
      application: "Bespoke Bathrooms, Fireplace Mantels, Pastry Rolling Islands",
      description: "Timeless Italian Carrara marble featuring a cool white-grey ground and feathered grey veining.",
      image1: "assets/images/stone-types/marble.jpg",
      image2: "assets/images/stone-types/marble.jpg",
      inStock: true
    },
    {
      id: "bianco-carrara-honed",
      name: "Bianco Carrara Honed",
      gtNumber: "",
      lotNumber: "LOT #62012",
      thickness: "3 cm",
      size: "120\" × 68\" · 56.7 sq. ft.",
      category: "marble",
      categoryLabel: "Marble",
      type: "natural",
      typeLabel: "Natural Metamorphic Marble",
      finish: "Honed",
      origin: "Italy (Carrara)",
      colors: ["white", "grey"],
      colorLabel: "Satin White, Smoky Veins",
      application: "Modern Matte Bathrooms, Walk-in Shower Walls",
      description: "Smooth satin honed finish on historic Carrara marble. Diffuses ambient light gently without glare.",
      image1: "assets/images/stone-types/marble.jpg",
      image2: "assets/images/stone-types/marble.jpg",
      inStock: true
    },
    {
      id: "bianco-rhino",
      name: "Bianco Rhino",
      gtNumber: "",
      lotNumber: "LOT #62013",
      thickness: "3 cm",
      size: "124\" × 72\" · 62.0 sq. ft.",
      category: "marble",
      categoryLabel: "Marble",
      type: "natural",
      typeLabel: "Natural Metamorphic Marble",
      finish: "Polished",
      origin: "Namibia",
      colors: ["white", "cream"],
      colorLabel: "Ultra-White, Translucent Cream",
      application: "Primary Suite Vanities, Low-Traffic Designer Islands",
      description: "Exquisite African white marble with subtle golden-beige clouds and near-translucent crystalline purity.",
      image1: "assets/images/stone-types/marble.jpg",
      image2: "assets/images/stone-types/marble.jpg",
      inStock: true
    },
    {
      id: "calacatta-zambia",
      name: "Calacatta Zambia",
      gtNumber: "",
      lotNumber: "LOT #62014",
      thickness: "3 cm",
      size: "126\" × 74\" · 64.8 sq. ft.",
      category: "marble",
      categoryLabel: "Marble",
      type: "natural",
      typeLabel: "Natural Metamorphic Marble",
      finish: "Polished",
      origin: "Zambia",
      colors: ["white", "grey", "gold"],
      colorLabel: "Bright White, Charcoal & Ochre Veining",
      application: "Luxury Waterfall Islands, Boutique Hotel Reception Walls",
      description: "Luminous white field broken by sweeping charcoal and ochre veining rivaling Italy’s finest Calacatta cuts.",
      image1: "assets/images/stone-types/marble.jpg",
      image2: "assets/images/stone-types/marble.jpg",
      inStock: true
    },
    {
      id: "crema-marfil",
      name: "Crema Marfil",
      gtNumber: "",
      lotNumber: "LOT #62015",
      thickness: "3 cm",
      size: "120\" × 70\" · 58.3 sq. ft.",
      category: "marble",
      categoryLabel: "Marble",
      type: "natural",
      typeLabel: "Natural Sedimentary Marble",
      finish: "Polished",
      origin: "Spain (Alicante)",
      colors: ["cream", "gold"],
      colorLabel: "Warm Beige, Cinnamon Veinlets",
      application: "Expansive Flooring, Bathroom Surrounds, Grand Foyers",
      description: "World-renowned Spanish beige marble with soft honey hues and delicate, irregular cinnamon veinlets.",
      image1: "assets/images/stone-types/marble.jpg",
      image2: "assets/images/stone-types/marble.jpg",
      inStock: true
    },
    {
      id: "dark-emperador",
      name: "Dark Emperador",
      gtNumber: "",
      lotNumber: "LOT #62016",
      thickness: "3 cm",
      size: "118\" × 68\" · 55.7 sq. ft.",
      category: "marble",
      categoryLabel: "Marble",
      type: "natural",
      typeLabel: "Natural Metamorphic Marble",
      finish: "Polished",
      origin: "Spain",
      colors: ["brown", "white"],
      colorLabel: "Rich Espresso, White Calcite",
      application: "Executive Suites, Library Fireplace Surrounds",
      description: "Rich dark brown to espresso ground laced with an intricate web of fine white and cream calcite veins.",
      image1: "assets/images/stone-types/marble.jpg",
      image2: "assets/images/stone-types/marble.jpg",
      inStock: true
    },
    {
      id: "dover-white",
      name: "Dover White",
      gtNumber: "",
      lotNumber: "LOT #62017",
      thickness: "3 cm",
      size: "125\" × 72\" · 62.5 sq. ft.",
      category: "marble",
      categoryLabel: "Marble",
      type: "natural",
      typeLabel: "Natural Metamorphic Marble",
      finish: "Polished",
      origin: "Italy",
      colors: ["white", "grey"],
      colorLabel: "Chalk White, Smoke Grey",
      application: "Feature Island Backdrops, Minimalist Powder Rooms",
      description: "Bold monochromatic Italian marble featuring large fluid patches of charcoal and dove grey across white.",
      image1: "assets/images/stone-types/marble.jpg",
      image2: "assets/images/stone-types/marble.jpg",
      inStock: true
    },
    {
      id: "forest-brown",
      name: "Forest Brown",
      gtNumber: "",
      lotNumber: "LOT #62018",
      thickness: "3 cm",
      size: "118\" × 66\" · 54.1 sq. ft.",
      category: "marble",
      categoryLabel: "Marble",
      type: "natural",
      typeLabel: "Natural Serpentine Marble",
      finish: "Polished",
      origin: "India",
      colors: ["brown", "green"],
      colorLabel: "Earthy Moss Brown, Tree-Branch Veins",
      application: "Organic Accent Walls, Spa Baths, Fireplace Hearths",
      description: "Intricately veined serpentine marble resembling tree root networks across a rich forest-floor brown field.",
      image1: "assets/images/stone-types/marble.jpg",
      image2: "assets/images/stone-types/marble.jpg",
      inStock: true
    },
    {
      id: "nero-marquina-marble",
      name: "Nero Marquina",
      gtNumber: "",
      lotNumber: "LOT #62019",
      thickness: "3 cm",
      size: "122\" × 70\" · 59.3 sq. ft.",
      category: "marble",
      categoryLabel: "Marble",
      type: "natural",
      typeLabel: "Natural Metamorphic Marble",
      finish: "Polished",
      origin: "Spain (Basque Country)",
      colors: ["black", "white"],
      colorLabel: "Coal Black, Striking White Calcite",
      application: "Powder Rooms, Geometric Floors, Cocktail Counters",
      description: "Deep black natural marble with irregular, striking white calcite veins cut directly from northern Spain.",
      image1: "assets/images/stone-types/marble.jpg",
      image2: "assets/images/stone-types/marble.jpg",
      inStock: true
    },
    {
      id: "sahara-beige-marble",
      name: "Sahara Beige",
      gtNumber: "",
      lotNumber: "LOT #62020",
      thickness: "3 cm",
      size: "120\" × 68\" · 56.7 sq. ft.",
      category: "marble",
      categoryLabel: "Marble",
      type: "natural",
      typeLabel: "Natural Metamorphic Marble",
      finish: "Polished",
      origin: "Turkey",
      colors: ["cream", "gold"],
      colorLabel: "Desert Dune Beige, Golden Filaments",
      application: "Classic Roman Flooring, Bath Walls, Thresholds",
      description: "Warm desert sand beige marble enriched with soft golden filaments and fossilized marine inclusions.",
      image1: "assets/images/stone-types/marble.jpg",
      image2: "assets/images/stone-types/marble.jpg",
      inStock: true
    },
    {
      id: "arabescato",
      name: "Arabescato",
      gtNumber: "",
      lotNumber: "LOT #62021",
      thickness: "3 cm",
      size: "124\" × 72\" · 62.0 sq. ft.",
      category: "marble",
      categoryLabel: "Marble",
      type: "natural",
      typeLabel: "Natural Brecciated Marble",
      finish: "Polished",
      origin: "Italy (Apuan Alps)",
      colors: ["white", "grey"],
      colorLabel: "Ivory White, Dusky Grey Breccia",
      application: "Waterfall Bookmatches, High-End Kitchen Focal Points",
      description: "Prestigious Italian brecciated marble with rounded grey arabesques dancing over an ivory crystalline background.",
      image1: "assets/images/stone-types/marble.jpg",
      image2: "assets/images/stone-types/marble.jpg",
      inStock: true
    },

    // ---------------- MONUMENTS (GT-000 series) ----------------
    {
      id: "gt-001",
      name: "GT 001 Black Granite Monument",
      gtNumber: "GT-001",
      lotNumber: "LOT #90101",
      thickness: "3 cm · 4 cm Monument Spec",
      size: "84\" × 48\" Monument Blank",
      category: "monuments",
      categoryLabel: "Monuments",
      type: "natural",
      typeLabel: "Monument-Grade Granite",
      finish: "Polished",
      origin: "India",
      colors: ["black"],
      colorLabel: "Dense Jet Black",
      application: "Cemetery Headstones, Civic Plaques, Permanent Memorials",
      description: "Dense, fine-grain black granite quarried specifically for memorial craftsmanship and outdoor weather endurance.",
      image1: "assets/images/stone-types/monuments.jpg",
      image2: "assets/images/stone-types/monuments.jpg",
      inStock: true
    },
    {
      id: "gt-002",
      name: "GT 002 Upright Memorial",
      gtNumber: "GT-002",
      lotNumber: "LOT #90102",
      thickness: "3 cm · 4 cm Monument Spec",
      size: "80\" × 46\" Monument Blank",
      category: "monuments",
      categoryLabel: "Monuments",
      type: "natural",
      typeLabel: "Monument-Grade Granite",
      finish: "Polished",
      origin: "India",
      colors: ["black", "grey"],
      colorLabel: "Obsidian Black, Polished Face",
      application: "Dual Companion Memorials, Civic Dedication Tablets",
      description: "All-face polished monument blank with uniform color density suited for sandblast or laser engraving.",
      image1: "assets/images/stone-types/monuments.jpg",
      image2: "assets/images/stone-types/monuments.jpg",
      inStock: true
    },
    {
      id: "gt-003",
      name: "GT 003 Die & Base Marker",
      gtNumber: "GT-003",
      lotNumber: "LOT #90103",
      thickness: "4 cm Monument Spec",
      size: "72\" × 36\" Monument Blank",
      category: "monuments",
      categoryLabel: "Monuments",
      type: "natural",
      typeLabel: "Monument-Grade Granite",
      finish: "Polished",
      origin: "India",
      colors: ["black"],
      colorLabel: "Mirror Black Finish",
      application: "Flat Grave Markers, Garden Dedication Pedestals",
      description: "Precision-sawn monument blank with rock-pitch edges and mirror-polished face.",
      image1: "assets/images/stone-types/monuments.jpg",
      image2: "assets/images/stone-types/monuments.jpg",
      inStock: true
    },
    {
      id: "gt-004",
      name: "GT 004 Slant Marker",
      gtNumber: "GT-004",
      lotNumber: "LOT #90104",
      thickness: "3 cm Monument Spec",
      size: "76\" × 40\" Monument Blank",
      category: "monuments",
      categoryLabel: "Monuments",
      type: "natural",
      typeLabel: "Monument-Grade Granite",
      finish: "Polished",
      origin: "India",
      colors: ["black"],
      colorLabel: "Fine-Grained Black",
      application: "Slanted Cemetery Markers, Family Estate Plots",
      description: "High-density granite blank calibrated to withstand northern freeze-thaw cycles without surface checking.",
      image1: "assets/images/stone-types/monuments.jpg",
      image2: "assets/images/stone-types/monuments.jpg",
      inStock: true
    },
    {
      id: "gt-005",
      name: "GT 005 Serpentine Top Monument",
      gtNumber: "GT-005",
      lotNumber: "LOT #90105",
      thickness: "4 cm Monument Spec",
      size: "82\" × 44\" Monument Blank",
      category: "monuments",
      categoryLabel: "Monuments",
      type: "natural",
      typeLabel: "Monument-Grade Granite",
      finish: "Polished",
      origin: "India",
      colors: ["black", "grey"],
      colorLabel: "Midnight Black, Grey Flecks",
      application: "Serpentine Headstones, Historical Plaque Bases",
      description: "Contoured top memorial block engineered for hand-carving, gold-leaf lettering, and bronze medallion mounting.",
      image1: "assets/images/stone-types/monuments.jpg",
      image2: "assets/images/stone-types/monuments.jpg",
      inStock: true
    },

    // ---------------- EXOTIC QUARTZITE (GT-4000 series) ----------------
    {
      id: "casablanca",
      name: "Casablanca Quartzite",
      gtNumber: "",
      lotNumber: "LOT #59101",
      thickness: "3 cm",
      size: "128\" × 76\" · 67.5 sq. ft.",
      category: "quartzite",
      categoryLabel: "Quartzite",
      type: "natural",
      typeLabel: "Natural Metamorphic Quartzite",
      finish: "Polished",
      origin: "Brazil",
      colors: ["white", "grey", "cream"],
      colorLabel: "Warm White, Ash Veining",
      application: "Chef Kitchen Islands, Luxury Backlit Surfaces",
      description: "Warm white metamorphic stone interlaced with soft ash and slate veining. High acid-resistance and superior hardness.",
      image1: "assets/images/stone-types/quartzite.jpg",
      image2: "assets/images/stone-types/quartzite.jpg",
      inStock: true
    },
    {
      id: "crystallo",
      name: "Crystallo Quartzite",
      gtNumber: "",
      lotNumber: "LOT #59102",
      thickness: "3 cm",
      size: "124\" × 72\" · 62.0 sq. ft.",
      category: "quartzite",
      categoryLabel: "Quartzite",
      type: "natural",
      typeLabel: "Natural Metamorphic Quartzite",
      finish: "Polished",
      origin: "Brazil",
      colors: ["white", "gold"],
      colorLabel: "Translucent Quartz, Amber Inclusions",
      application: "Backlit Cocktail Bars, High-End Feature Walls",
      description: "Nearly translucent Brazilian quartzite loaded with crystalline quartz veins. Backlighting brings the entire slab to radiant life.",
      image1: "assets/images/stone-types/quartzite.jpg",
      image2: "assets/images/stone-types/quartzite.jpg",
      inStock: true
    },
    {
      id: "deep-blue",
      name: "Deep Blue Quartzite",
      gtNumber: "",
      lotNumber: "LOT #59103",
      thickness: "3 cm",
      size: "126\" × 74\" · 64.8 sq. ft.",
      category: "quartzite",
      categoryLabel: "Quartzite",
      type: "natural",
      typeLabel: "Natural Metamorphic Quartzite",
      finish: "Polished",
      origin: "Brazil (Bahia)",
      colors: ["blue", "grey"],
      colorLabel: "Oceanic Indigo, Silver Currents",
      application: "Dramatic Kitchen Islands, Powder Room Feature Slabs",
      description: "Intense cobalt and oceanic blue waves crashing across a dense crystalline matrix. A showpiece stone from Bahia.",
      image1: "assets/images/stone-types/quartzite.jpg",
      image2: "assets/images/stone-types/quartzite.jpg",
      inStock: true
    },
    {
      id: "fantasy-brown",
      name: "Fantasy Brown",
      gtNumber: "",
      lotNumber: "LOT #59104",
      thickness: "3 cm",
      size: "130\" × 78\" · 70.4 sq. ft.",
      category: "quartzite",
      categoryLabel: "Quartzite",
      type: "natural",
      typeLabel: "Natural Metamorphic Stone",
      finish: "Leathered",
      origin: "India (Rajasthan)",
      colors: ["brown", "grey", "cream"],
      colorLabel: "Caramel, Sage Grey, Ivory",
      application: "Sprawling Kitchen Countertops, Waterfall Edges",
      description: "Spectacular flowing geological waves of caramel, sage grey, and cream. Textured leathered finish.",
      image1: "assets/images/stone-types/quartzite.jpg",
      image2: "assets/images/stone-types/quartzite.jpg",
      inStock: true
    },
    {
      id: "grey-quartzite-leather",
      name: "Grey Quartzite Leather",
      gtNumber: "",
      lotNumber: "LOT #59105",
      thickness: "3 cm",
      size: "128\" × 75\" · 66.7 sq. ft.",
      category: "quartzite",
      categoryLabel: "Quartzite",
      type: "natural",
      typeLabel: "Natural Metamorphic Quartzite",
      finish: "Leathered",
      origin: "Brazil",
      colors: ["grey"],
      colorLabel: "Steel Grey, Charcoal Veins",
      application: "Modern Matte Kitchens, Tactile Bar Tops",
      description: "Soft tactile leathered finish on a uniform steel-grey quartzite. Scratch-proof, acid-proof, and deeply durable.",
      image1: "assets/images/stone-types/quartzite.jpg",
      image2: "assets/images/stone-types/quartzite.jpg",
      inStock: true
    },
    {
      id: "river-blue",
      name: "River Blue Quartzite",
      gtNumber: "",
      lotNumber: "LOT #59106",
      thickness: "3 cm",
      size: "125\" × 73\" · 63.4 sq. ft.",
      category: "quartzite",
      categoryLabel: "Quartzite",
      type: "natural",
      typeLabel: "Natural Metamorphic Quartzite",
      finish: "Polished",
      origin: "Brazil",
      colors: ["blue", "grey", "white"],
      colorLabel: "Riverbed Slate Blue, Cream Strata",
      application: "Architectural Feature Islands, Master Vanities",
      description: "Flowing horizontal currents of sky blue, smoky slate, and cream mimicking the visual movement of river water.",
      image1: "assets/images/stone-types/quartzite.jpg",
      image2: "assets/images/stone-types/quartzite.jpg",
      inStock: true
    },
    {
      id: "taj-mahal",
      name: "Taj Mahal Quartzite",
      gtNumber: "",
      lotNumber: "LOT #59107",
      thickness: "3 cm",
      size: "132\" × 78\" · 71.5 sq. ft.",
      category: "quartzite",
      categoryLabel: "Quartzite",
      type: "natural",
      typeLabel: "Natural Metamorphic Quartzite",
      finish: "Polished",
      origin: "Brazil (Ceará)",
      colors: ["cream", "gold", "white"],
      colorLabel: "Creamy Alabaster, Warm Gold Strata",
      application: "Luxury Kitchen Perimeters, Massive Islands, Full Walls",
      description: "The gold standard of natural quartzite. Warm creamy alabaster with subtle golden and bronze strata. Impervious to household acids.",
      image1: "assets/images/stone-types/quartzite.jpg",
      image2: "assets/images/stone-types/quartzite.jpg",
      inStock: true
    },
    {
      id: "aquamarine-quartzite",
      name: "Aquamarine Quartzite",
      gtNumber: "",
      lotNumber: "LOT #59108",
      thickness: "3 cm",
      size: "128\" × 76\" · 67.5 sq. ft.",
      category: "quartzite",
      categoryLabel: "Quartzite",
      type: "natural",
      typeLabel: "Natural Metamorphic Quartzite",
      finish: "Polished",
      origin: "Brazil (Bahia)",
      colors: ["blue", "green", "grey"],
      colorLabel: "Oceanic Teal, Emerald & Crystalline Veining",
      application: "Signature Statement Islands, Backlit Showpieces",
      description: "Surging oceanic teal-green crystalline currents, deep mineral fissures, and sea-foam veining. High acid-resistance and superior hardness.",
      image1: "assets/images/aquamarine-slab-1.jpg",
      image2: "assets/images/aquamarine-slab-2.jpg",
      inStock: true
    },

    // ---------------- SOAPSTONE (GT-5000 series) ----------------
    {
      id: "graphite-soapstone",
      name: "Graphite Soapstone",
      gtNumber: "GT-5001",
      lotNumber: "LOT #48201",
      thickness: "3 cm",
      size: "116\" × 64\" · 51.5 sq. ft.",
      category: "soapstone",
      categoryLabel: "Soapstone",
      type: "natural",
      typeLabel: "Natural Steatite Stone",
      finish: "Honed",
      origin: "Brazil / USA",
      colors: ["grey", "black"],
      colorLabel: "Silky Charcoal, Soft Quartz Veins",
      application: "Rustic Farmhouse Kitchens, Chemistry Prep Labs, Fireplaces",
      description: "Silky matte charcoal soapstone impervious to kitchen acids, oils, and intense cookware heat. Develops rich patina over time.",
      image1: "assets/images/stone-types/soapstone.jpg",
      image2: "assets/images/stone-types/soapstone.jpg",
      inStock: true
    },
    {
      id: "green-soapstone",
      name: "Green Soapstone",
      gtNumber: "GT-5002",
      lotNumber: "LOT #48202",
      thickness: "3 cm",
      size: "114\" × 62\" · 49.1 sq. ft.",
      category: "soapstone",
      categoryLabel: "Soapstone",
      type: "natural",
      typeLabel: "Natural Steatite Stone",
      finish: "Honed",
      origin: "Brazil",
      colors: ["green", "grey"],
      colorLabel: "Deep Olive Green, Fine Veins",
      application: "Country Kitchen Counters, Wood Stove Hearths",
      description: "Deep olive-toned soapstone with subtle mineral veins that darken and deepen dramatically when oiled.",
      image1: "assets/images/stone-types/soapstone.jpg",
      image2: "assets/images/stone-types/soapstone.jpg",
      inStock: true
    },

    // ---------------- SEMI PRECIOUS (GT-6000 series) ----------------
    {
      id: "semi-precious-blue-agate",
      name: "Blue Agate Geode Slab",
      gtNumber: "GT-6001",
      lotNumber: "LOT #32001",
      thickness: "3 cm Backlit",
      size: "110\" × 58\" · 44.3 sq. ft.",
      category: "semi",
      categoryLabel: "Semi Precious",
      type: "natural",
      typeLabel: "Hand-Composed Gemstone Mosaic",
      finish: "Polished",
      origin: "Brazil / Madagascar",
      colors: ["blue", "white", "gold"],
      colorLabel: "Royal Blue Geodes, Optical Resin",
      application: "VIP Cocktail Lounges, Backlit Reception Murals, Powder Rooms",
      description: "Rare hand-composed mosaic of genuine blue agate geodes bound in optical resin. Stunning translucency under LED backlighting.",
      image1: "assets/images/stone-types/semi-precious.jpg",
      image2: "assets/images/stone-types/semi-precious.jpg",
      inStock: true
    },

    // ---------------- ARCHITECTURAL TILE (GT-7000 series) ----------------
    {
      id: "travertino-classico",
      name: "Travertino Classico",
      gtNumber: "GT-7001",
      lotNumber: "LOT #21001",
      thickness: "1.2 cm Tile",
      size: "24\" × 24\" / 12\" × 24\" Tile Crate",
      category: "tile",
      categoryLabel: "Tiles",
      type: "natural",
      typeLabel: "Natural Travertine",
      finish: "Honed / Filled",
      origin: "Italy (Tivoli)",
      colors: ["cream", "brown"],
      colorLabel: "Warm Roman Cream, Earth Tones",
      application: "Luxury Villa Flooring, Shower Walls, Outdoor Loggias",
      description: "Classic Roman travertine tiles celebrating warm natural cavities, soft earthy linear banding, and tactile warmth.",
      image1: "assets/images/stone-types/tile.jpg",
      image2: "assets/images/stone-types/tile.jpg",
      inStock: true
    }
  ];

  const OVERRIDES_KEY = "granTrade_stone_overrides_v1";
  const BUILTIN_COLOR_LABELS = {
    blue: "Blue / Teal",
    green: "Green",
    white: "White",
    grey: "Grey",
    black: "Black",
    gold: "Gold / Amber",
    cream: "Cream / Beige",
    brown: "Brown",
    red: "Red",
  };
  const COLOR_HEX_MAP = {
    white: "#f3f4f6",
    cream: "#ede0cc",
    beige: "#e6d7be",
    ivory: "#f5f1e6",
    grey: "#8b929a",
    gray: "#8b929a",
    silver: "#b8bec6",
    charcoal: "#3f444c",
    black: "#1f2328",
    blue: "#2f6b8a",
    navy: "#1e3a5f",
    teal: "#1b7a78",
    aquamarine: "#2e8b89",
    seafoam: "#5ea396",
    green: "#2f6e49",
    emerald: "#197a52",
    olive: "#5f6b3a",
    sage: "#7d937e",
    gold: "#c7963e",
    amber: "#b87424",
    bronze: "#8c6239",
    brown: "#7c5238",
    taupe: "#8d7b6b",
    red: "#9e3333",
    burgundy: "#6b232e",
  };

  function normalizeColorTags(input) {
    const rawList = Array.isArray(input)
      ? input
      : String(input || "").split(/[,;|]+/);
    const seen = new Set();
    const out = [];
    rawList.forEach((item) => {
      const clean = String(item || "").trim().toLowerCase().replace(/\s+/g, " ");
      if (clean && !seen.has(clean)) {
        seen.add(clean);
        out.push(clean);
      }
    });
    return out;
  }

  function formatColorLabel(tag) {
    const clean = String(tag || "").trim().toLowerCase();
    if (!clean) return "";
    if (BUILTIN_COLOR_LABELS[clean]) return BUILTIN_COLOR_LABELS[clean];
    return clean.replace(/\b\w/g, (ch) => ch.toUpperCase());
  }

  function getColorSwatch(tag) {
    const clean = String(tag || "").trim().toLowerCase();
    const wpCustom = global.GRAN_TRADE_ENV && global.GRAN_TRADE_ENV.customColors;
    if (wpCustom && wpCustom[clean] && wpCustom[clean].hex) return wpCustom[clean].hex;
    if (COLOR_HEX_MAP[clean]) return COLOR_HEX_MAP[clean];
    const words = clean.split(/\s+/);
    for (let i = 0; i < words.length; i++) {
      if (wpCustom && wpCustom[words[i]] && wpCustom[words[i]].hex) return wpCustom[words[i]].hex;
      if (COLOR_HEX_MAP[words[i]]) return COLOR_HEX_MAP[words[i]];
    }
    let hash = 0;
    for (let i = 0; i < clean.length; i++) {
      hash = (clean.charCodeAt(i) + ((hash << 5) - hash)) | 0;
    }
    return `hsl(${Math.abs(hash) % 360}, 36%, 46%)`;
  }

  function readOverrides() {
    try {
      const raw = global.localStorage && global.localStorage.getItem(OVERRIDES_KEY);
      if (!raw) return {};
      const parsed = JSON.parse(raw);
      return parsed && typeof parsed === "object" ? parsed : {};
    } catch (_) {
      return {};
    }
  }

  function writeOverrides(map) {
    try {
      if (global.localStorage) {
        global.localStorage.setItem(OVERRIDES_KEY, JSON.stringify(map));
      }
    } catch (_) {}
  }

  const NO_GT_CATEGORIES = new Set(["granite", "quartzite", "marble"]);
  const CATEGORY_LABELS = {
    quartzite: "Quartzite",
    quartz: "Quartz",
    granite: "Granite",
    marble: "Marble",
    monuments: "Monuments",
    soapstone: "Soapstone",
    semi: "Semi Precious",
    tile: "Tiles",
  };

  function getCategoryLabel(cat, fallback) {
    const key = String(cat || "").toLowerCase().trim();
    if (CATEGORY_LABELS[key]) return CATEGORY_LABELS[key];
    return fallback || cat || "";
  }

  function normalizeThickness(raw) {
    if (raw === null || raw === undefined) return "";
    const str = String(raw).trim();
    if (!str) return "";
    const cleaned = (/calibrated/i.test(str)
      ? str.replace(/\b2\s*cm\s*·\s*3\s*cm/gi, "3 cm").replace(/\bcalibrated\b/gi, "")
      : str
    )
      .replace(/\s{2,}/g, " ")
      .replace(/\s*·\s*$/g, "")
      .trim();
    return cleaned;
  }

  function cloneStone(s) {
    return Object.assign({}, s, {
      colors: Array.isArray(s.colors) ? s.colors.slice() : normalizeColorTags(s.colors),
      tags: Array.isArray(s.tags) ? s.tags.slice() : (s.tags || []),
    });
  }

  function hasGtNumber(stoneOrCategory) {
    if (!stoneOrCategory) return false;
    if (typeof stoneOrCategory === "string") {
      return !NO_GT_CATEGORIES.has(stoneOrCategory.toLowerCase().trim());
    }
    const cat = String(stoneOrCategory.category || "").toLowerCase().trim();
    if (NO_GT_CATEGORIES.has(cat)) return false;
    return Boolean(stoneOrCategory.gtNumber && String(stoneOrCategory.gtNumber).trim());
  }

  function normalizeStone(stone) {
    if (!stone || typeof stone !== "object") return stone;
    const cat = String(stone.category || "").toLowerCase().trim();
    if (NO_GT_CATEGORIES.has(cat)) {
      stone.gtNumber = "";
    }
    if (CATEGORY_LABELS[cat]) {
      stone.categoryLabel = CATEGORY_LABELS[cat];
    }
    if (stone.thickness !== undefined) {
      stone.thickness = normalizeThickness(stone.thickness);
    }
    stone.colors = normalizeColorTags(stone.colors);
    return stone;
  }

  // Pristine base snapshot & WordPress CPT overlay store
  const INITIAL_STONES = STONES.map((s) => normalizeStone(cloneStone(s)));
  let externalStones = [];
  let externalReplaceBuiltin = false;

  // Helper dictionary keyed by ID (mutated in-place on refresh so references stay valid)
  const STONES_BY_ID = {};

  function applyLocalOverrides() {
    const baseList = externalReplaceBuiltin ? [] : INITIAL_STONES.map(cloneStone);
    const byId = new Map();
    baseList.forEach((item) => {
      if (item && item.id) byId.set(item.id, item);
    });

    externalStones.forEach((extStone) => {
      if (!extStone || !extStone.id) return;
      if (byId.has(extStone.id)) {
        Object.assign(byId.get(extStone.id), cloneStone(extStone));
      } else {
        const copy = cloneStone(extStone);
        baseList.unshift(copy);
        byId.set(copy.id, copy);
      }
    });

    const overrides = readOverrides();
    const deletedIds = new Set();

    Object.keys(overrides).forEach((id) => {
      const patch = overrides[id];
      if (!patch || typeof patch !== "object") return;
      if (patch._deleted) {
        deletedIds.add(id);
        return;
      }
      if (byId.has(id)) {
        const target = byId.get(id);
        Object.assign(target, patch);
        normalizeStone(target);
      } else if (!externalReplaceBuiltin && patch.name) {
        const created = normalizeStone(Object.assign({ id }, cloneStone(patch)));
        baseList.unshift(created);
        byId.set(id, created);
      }
    });

    const finalList = baseList
      .filter((s) => s && s.id && !deletedIds.has(s.id))
      .map((s) => normalizeStone(s));

    STONES.length = 0;
    Object.keys(STONES_BY_ID).forEach((k) => {
      delete STONES_BY_ID[k];
    });
    finalList.forEach((s) => {
      STONES.push(s);
      STONES_BY_ID[s.id] = s;
    });

    return STONES;
  }

  applyLocalOverrides();

  global.GRAN_TRADE_CATALOG = {
    all: STONES,
    byId: STONES_BY_ID,
    categoryLabels: Object.assign({}, CATEGORY_LABELS),
    noGtCategories: Array.from(NO_GT_CATEGORIES),
    getCategoryLabel,
    hasGtNumber,
    normalizeColorTags,
    formatColorLabel,
    getColorSwatch,
    applyLocalOverrides,
    refresh: function () {
      return applyLocalOverrides();
    },
    setExternalStones: function (list, replaceBuiltin) {
      externalStones = Array.isArray(list) ? list.map(cloneStone) : [];
      externalReplaceBuiltin = Boolean(replaceBuiltin);
      return applyLocalOverrides();
    },
    saveOverride: function (id, patch) {
      if (!id || !patch || typeof patch !== "object") return null;
      const overrides = readOverrides();
      const prev = overrides[id] ? Object.assign({}, overrides[id]) : {};
      delete prev._deleted;
      const nextPatch = Object.assign(prev, patch);
      if ("colors" in patch) {
        nextPatch.colors = normalizeColorTags(patch.colors);
      }
      if (nextPatch.category && CATEGORY_LABELS[nextPatch.category]) {
        nextPatch.categoryLabel = CATEGORY_LABELS[nextPatch.category];
      }
      overrides[id] = nextPatch;
      writeOverrides(overrides);
      applyLocalOverrides();
      return STONES_BY_ID[id] || null;
    },
    deleteOverride: function (id) {
      if (!id) return false;
      const overrides = readOverrides();
      const isCustomOnly = !INITIAL_STONES.some((s) => s.id === id) && !externalStones.some((s) => s.id === id);
      if (isCustomOnly) {
        delete overrides[id];
      } else {
        overrides[id] = { _deleted: true };
      }
      writeOverrides(overrides);
      applyLocalOverrides();
      return true;
    },
    clearOverrides: function () {
      try {
        if (global.localStorage) global.localStorage.removeItem(OVERRIDES_KEY);
      } catch (_) {}
      return applyLocalOverrides();
    },
    saveColorTags: function (id, tags) {
      const normalized = normalizeColorTags(tags);
      this.saveOverride(id, { colors: normalized });
      return normalized;
    },
    getAllColorTags: function () {
      const seen = new Set(Object.keys(BUILTIN_COLOR_LABELS));
      const extras = [];
      STONES.forEach((s) => {
        normalizeColorTags(s.colors).forEach((c) => {
          if (!seen.has(c)) {
            seen.add(c);
            extras.push(c);
          }
        });
      });
      extras.sort((a, b) => a.localeCompare(b));
      return Object.keys(BUILTIN_COLOR_LABELS).concat(extras);
    },
    getById: function (id) {
      if (!id) return STONES[0];
      const clean = String(id).toLowerCase().trim();
      return STONES_BY_ID[clean] || STONES.find((s) => s.name.toLowerCase() === clean) || STONES[0];
    }
  };
})(typeof window !== "undefined" ? window : this);
